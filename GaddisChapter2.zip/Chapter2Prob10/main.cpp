/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 10
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Display personal info
    
    cout<<"Charles Carsten\n Riverside\n California\n 92509\n 9512145319\n Computer Science"<<endl;
    
    
    //Exit stage left
    return 0;
}

