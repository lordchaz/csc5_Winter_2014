/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 1
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    int num1=62, num2=99, total=num1+num2;
    
    //Print the total
    cout<<"The total of 62 and 99 is "<<total <<"." <<endl;
    
    //Exit stage left
    return 0;
}

