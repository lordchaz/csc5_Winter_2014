/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 3
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    float Purchase=52, StateTax=Purchase*0.04, CountyTax=Purchase*0.02,
            TotalTax=StateTax+CountyTax;
    
    //Print the total
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The purchase price is $"<<Purchase <<"." <<endl;
    cout<<"The State Tax is $"<<StateTax <<"." <<endl;
    cout<<"The County Tax is $"<<CountyTax <<"." <<endl;
    cout<<"The Total Tax is $"<<TotalTax <<"." <<endl;
    
    //Exit stage left
    return 0;
}

