/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 8
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Display distance per tank of gas
    float qtrAcre=43560*0.25, qtrInMeters=qtrAcre*10.7639;
    
    cout<< setprecision(4) << showpoint << fixed;
    cout<<"The size of a quarter acre of land in square feet is "<<qtrAcre <<"." <<endl;
    cout<<"The size of a quarter acre of land in square meters is "<<qtrInMeters <<"." <<endl;
    
    //Exit stage left
    return 0;
}

