/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 5
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Print size of data types
    cout<<"The size of a char is "<<sizeof(char) <<"bytes." <<endl;
    cout<<"The size of an int is "<<sizeof(int) <<"bytes." <<endl;
    cout<<"The size of a float is "<<sizeof(float) <<"bytes." <<endl;
    cout<<"The size of a double is "<<sizeof(double) <<"bytes." <<endl;
    
    //Exit stage left
    return 0;
}

