/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 7
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Display distance per tank of gas
    float gallons=20, inTown=gallons*21.5, onHwy=gallons*26.6;
    
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The distance the car can travel in town is "<<inTown <<" miles." <<endl;
    cout<<"The distance the car can travel on the highway is "<<onHwy <<" miles." <<endl;
    
    //Exit stage left
    return 0;
}

