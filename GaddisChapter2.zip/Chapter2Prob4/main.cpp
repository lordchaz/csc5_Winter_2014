/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 4
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    float MealCost = 44.50;
    float Tax=MealCost*.0675;
    float Tip=(MealCost+Tax)*0.15;
    float TotalBill=MealCost+Tax+Tip;
    
    //Print the total
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The Cost of the Meal is $"<<MealCost <<"." <<endl;
    cout<<"The Tax is $"<<Tax <<"." <<endl;
    cout<<"The Tip is $"<<Tip <<"." <<endl;
    cout<<"The Total Bill is $"<<TotalBill <<"." <<endl;
    
    //Exit stage left
    return 0;
}

