/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 2
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    float EC=0.62, Sales=4600000, PredESales=EC*Sales;
    
    //Print the total
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The predicted sales is $"<<PredESales <<"." <<endl;
    
    //Exit stage left
    return 0;
}

