/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 6
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Display miles per gallon
    float miles=350, gallons=16, mpg=miles/gallons;
    
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The size the gas tank is "<<gallons <<" gallons of gas." <<endl;
    cout<<"The car can travel "<<miles <<" miles." <<endl;
    cout<<"The car gets "<<mpg <<" miles per gallon." <<endl;
    
    //Exit stage left
    return 0;
}

