/* 
 * File:   main.cpp
 * Author: Charles Carsten
 * Gaddis Chapter 2 Problem 9
 *
 * Created on January 13, 2014, 12:16 PM
 */

//System Libraries

#include <iostream>
#include <iomanip>

//Global Constants

//Function Prototypes

//Execution Begins Here
using namespace std;


int main(int argc, char** argv) {
    
    //Display distance per tank of gas
    float cost=12.67, profit=cost*0.40, salePrice=cost+profit;
    
    cout<< setprecision(2) << showpoint << fixed;
    cout<<"The sale price with a 40% profit is $"<<salePrice <<"." <<endl;
    
    //Exit stage left
    return 0;
}

